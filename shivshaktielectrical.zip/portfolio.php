<!DOCTYPE html>
<html lang="en-US" prefix="og: https://ogp.me/ns#">

<?php include("headtag.php");  ?>

<body class="page-template-default page page-id-1384 qode-quick-links-1.0  qode-theme-ver-12.1.1 qode-theme-bridge wpb-js-composer js-comp-ver-6.0.5 vc_responsive" itemscope itemtype="http://schema.org/WebPage">
    <!--  Clickcease.com tracking-->
    <script type="text/javascript">
        var script = document.createElement("script");
        script.async = true;
        script.type = "text/javascript";
        var target = 'https://www.clickcease.com/monitor/stat.js';
        script.src = target;
        var elem = document.head;
        elem.appendChild(script);
    </script>
    <noscript><a href="https://www.clickcease.com" rel="nofollow"><img src="https://monitor.clickcease.com/stats/stats.aspx" alt="ClickCease" /></a></noscript>
    <!--  Clickcease.com tracking-->

    <div class="wrapper">
        <div class="wrapper_inner">


            <!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=UA-112462302-1"></script>
            <script>
                window.dataLayer = window.dataLayer || [];

                function gtag() {
                    dataLayer.push(arguments);
                }
                gtag('js', new Date());

                gtag('config', 'UA-112462302-1');
            </script>
            <!-- End Global site tag (gtag.js) - Google Analytics -->






            <?php include("header.php");  ?>


            <a id='back_to_top' href='#'>
                <span class="fa-stack">
                    <i class="fa fa-arrow-up" style=""></i>
                </span>
            </a>





            <div class="content ">
                <div class="content_inner  ">
                    <div class="title_outer title_without_animation" data-height="416">
                        <div class="title title_size_large  position_left  has_fixed_background " style="background-size:1280px auto;background-image:url(Assets/images/port.jpg);height:416px;background-color:#F6F6F6;">
                            <div class="image not_responsive"><img itemprop="image" src="Assets/images/port.jpg" alt="&nbsp;" /> </div>
                            <div class="title_holder" style="padding-top:101px;height:315px;">
                                <div class="container">
                                    <div class="container_inner clearfix">
                                        <div class="title_subtitle_holder">
                                            <div class="title_subtitle_holder_inner">
                                                <h1><span>Accessories</span></h1>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="container">
                        <div class="container_inner default_template_holder clearfix page_container_inner">
                            <div class="vc_row wpb_row section vc_row-fluid  vc_custom_1454970276339" style=' text-align:left;'>
                                <div class=" full_section_inner clearfix">
                                    <div class="wpb_column vc_column_container vc_col-sm-12">
                                        <div class="vc_column-inner">
                                            <div class="wpb_wrapper">
                                                <div class='projects_holder_outer v3 portfolio_with_space portfolio_standard  masonry_with_space'>
                                                    <div class='filter_outer'>
                                                        <div class='filter_holder'>
                                                            <ul>
                                                                <li class='filter' data-filter='*'><span>All WORK BY Shiv Shakti ELECTIRCALS</span></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class='projects_holder portfolio_main_holder clearfix v3 standard portfolio_full_image '>
                                                        <div class="qode-portfolio-masonry-gallery-grid-sizer"></div>
                                                        <div class="qode-portfolio-masonry-gallery-grid-gutter"></div>
                                                        <article class='mix portfolio_category_112 ' style=''>
                                                            <div class='image_holder'><a itemprop='url' class='portfolio_link_for_touch' href='#' target='_self'><span class='image'><img width="700" height="1050" src="Assets/images/ashu1.jpeg" class="attachment-portfolio_masonry_with_space size-portfolio_masonry_with_space wp-post-image" alt="" /></span></a><span class='text_holder'><span class='text_outer'><span class='text_inner'><span class='feature_holder'><span class="feature_holder_icons"><a itemprop='image' class='lightbox qbutton small white' title='Anmore Luxury Home (8500 sq ft)' href='Assets/images/ashu1.jpeg' data-rel='prettyPhoto[pretty_photo_gallery]'>zoom</a><!-- <a itemprop='url' class='preview qbutton small white' href='http://www.hallelectrical.ca/portfolio_page/anmore-luxury-home-8500-sq-ft/' target='_self'>view</a> --></span></span></span></span></span></div>
                                                            <div class='portfolio_description '>
                                                                <h5 itemprop="name" class="portfolio_title entry_title"><a itemprop="url" href="#" target="_self">DP </a></h5>
                                                            </div>
                                                        </article>
                                                        <article class='mix portfolio_category_112 ' style=''>
                                                            <div class='image_holder'><a itemprop='url' class='portfolio_link_for_touch' href='#' target='_self'><span class='image'><img width="700" height="465" src="Assets/images/ashu2.jpg" class="attachment-portfolio_masonry_with_space size-portfolio_masonry_with_space wp-post-image" alt="" /></span></a><span class='text_holder'><span class='text_outer'><span class='text_inner'><span class='feature_holder'><span class="feature_holder_icons"><a itemprop='image' class='lightbox qbutton small white' title='North Shore Custom Home (5000 sq ft)' href='Assets/images/ashu2.jpg' data-rel='prettyPhoto[pretty_photo_gallery]'>zoom</a><a itemprop='url' class='preview qbutton small white' href='Assets/images/ashu2.jpg' target='_self'>view</a> </span></span></span></span></span></div>
                                                            <div class='portfolio_description '>
                                                                <h5 itemprop="name" class="portfolio_title entry_title"><a itemprop="url" href="#" target="_self">WORKSHOP TOOLS</a></h5>
                                                            </div>
                                                        </article>
                                                        <article class='mix portfolio_category_112 ' style=''>
                                                            <div class='image_holder'><a itemprop='url' class='portfolio_link_for_touch' href='#' target='_self'><span class='image'><img width="700" height="467" src="Assets/images/ashu3.webp" class="attachment-portfolio_masonry_with_space size-portfolio_masonry_with_space wp-post-image" alt="" /></span></a><span class='text_holder'><span class='text_outer'><span class='text_inner'><span class='feature_holder'><span class="feature_holder_icons"><a itemprop='image' class='lightbox qbutton small white' title='Aura Restaurant at Nitka Lake Lodge' href='Assets/images/ashu3.webp' data-rel='prettyPhoto[pretty_photo_gallery]'>zoom</a> <!-- <a itemprop='url' class='preview qbutton small white' href='http://www.hallelectrical.ca/portfolio_page/aura-restaurant-nitka-lake-lodge/' target='_self'>view</a> --></span></span></span></span></span></div>
                                                            <div class='portfolio_description '>
                                                                <h5 itemprop="name" class="portfolio_title entry_title"><a itemprop="url" href="#" target="_self">Light Check Solutions</a></h5>
                                                            </div>
                                                        </article>
                                                        <article class='mix portfolio_category_112 ' style=''>
                                                            <div class='image_holder'><a itemprop='url' class='portfolio_link_for_touch' href='#' target='_self'><span class='image'><img width="700" height="525" src="Assets/images/ashu4.jpg" class="attachment-portfolio_masonry_with_space size-portfolio_masonry_with_space wp-post-image" alt="" /></span></a><span class='text_holder'><span class='text_outer'><span class='text_inner'><span class='feature_holder'><span class="feature_holder_icons"><a itemprop='image' class='lightbox qbutton small white' title='Drake Street Condo' href='Assets/images/ashu.jpg' data-rel='prettyPhoto[pretty_photo_gallery]'>zoom</a><!-- <a itemprop='url' class='preview qbutton small white' href='http://www.hallelectrical.ca/portfolio_page/drake-street-condo/' target='_self'>view</a> --></span></span></span></span></span></div>
                                                            <div class='portfolio_description '>
                                                                <h5 itemprop="name" class="portfolio_title entry_title"><a itemprop="url" href="#" target="_self">LED</a></h5>
                                                            </div>
                                                        </article>
                                                        <article class='mix portfolio_category_112 ' style=''>
                                                            <div class='image_holder'><a itemprop='url' class='portfolio_link_for_touch' href='#' target='_self'><span class='image'><img width="700" height="1050" src="Assets/images/ashu5.jpg" class="attachment-portfolio_masonry_with_space size-portfolio_masonry_with_space wp-post-image" alt="" srcset="Assets/images/ashu5.jpg 683w" sizes="(max-width: 700px) 100vw, 700px" /></span></a><span class='text_holder'><span class='text_outer'><span class='text_inner'><span class='feature_holder'><span class="feature_holder_icons"><a itemprop='image' class='lightbox qbutton small white' title='Yaletown Condo' href='Assets/images/ashu5.jpg' data-rel='prettyPhoto[pretty_photo_gallery]'>zoom</a><!-- <a itemprop='url' class='preview qbutton small white' href='http://www.hallelectrical.ca/portfolio_page/yaletowncondo/' target='_self'>view</a> --> </span></span></span></span></span></div>
                                                            <div class='portfolio_description '>
                                                                <h5 itemprop="name" class="portfolio_title entry_title"><a itemprop="url" href="#" target="_self">Electrical Conduits Fittings </a></h5>
                                                            </div>
                                                        </article>
                                                        <article class='mix portfolio_category_112 ' style=''>
                                                            <div class='image_holder'><a itemprop='url' class='portfolio_link_for_touch' href='#' target='_self'><span class='image'><img width="700" height="525" src="Assets/images/ashu6.jpg" class="attachment-portfolio_masonry_with_space size-portfolio_masonry_with_space wp-post-image" alt="" srcset="Assets/images/ashu6.jpg 1280w, Assets/images/ashu6.jpg 300w, Assets/images/ashu6.jpg 768w, Assets/images/ashu6.jpg 1024w" sizes="(max-width: 700px) 100vw, 700px" /></span></a><span class='text_holder'><span class='text_outer'><span class='text_inner'><span class='feature_holder'><span class="feature_holder_icons"><a itemprop='image' class='lightbox qbutton small white' title='West End Condo' href='Assets/images/ashu6.jpg' data-rel='prettyPhoto[pretty_photo_gallery]'>zoom</a><!-- <a itemprop='url' class='preview qbutton small white' href='http://www.hallelectrical.ca/portfolio_page/westendcondo/' target='_self'>view</a> --> </span></span></span></span></span></div>
                                                            <div class='portfolio_description '>
                                                                <h5 itemprop="name" class="portfolio_title entry_title"><a itemprop="url" href="#" target="_self">TRANSMISSION LINES SANGAMNER, 11KV 33KV</a></h5>
                                                            </div>
                                                        </article>
                                                        <article class='mix portfolio_category_112 ' style=''>
                                                            <div class='image_holder'><a itemprop='url' class='portfolio_link_for_touch' href='#' target='_self'><span class='image'><img width="700" height="525" src="Assets/images/ashu7.jpg" class="attachment-portfolio_masonry_with_space size-portfolio_masonry_with_space wp-post-image" alt="" srcset="Assets/images/ashu7.jpg 1131w" sizes="(max-width: 700px) 100vw, 700px" /></span></a><span class='text_holder'><span class='text_outer'><span class='text_inner'><span class='feature_holder'><span class="feature_holder_icons"><a itemprop='image' class='lightbox qbutton small white' title='North Shore Custom Home' href='Assets/images/ashu7.jpg' data-rel='prettyPhoto[pretty_photo_gallery]'>zoom</a><!--  <a itemprop='url' class='preview qbutton small white' href='http://www.hallelectrical.ca/portfolio_page/venice-art-pavilion/' target='_self'>view</a> --></span></span></span></span></span></div>
                                                            <div class='portfolio_description '>
                                                                <h5 itemprop="name" class="portfolio_title entry_title"><a itemprop="url" href="#" target="_self">KV</a></h5>
                                                            </div>
                                                        </article>
                                                        <article class='mix portfolio_category_112 ' style=''>
                                                            <div class='image_holder'><a itemprop='url' class='portfolio_link_for_touch' href='#' target='_self'><span class='image'><img width="700" height="467" src="Assets/images/ashu8.webp" class="attachment-portfolio_masonry_with_space size-portfolio_masonry_with_space wp-post-image" alt="" srcset="Assets/images/ashu8.webp" sizes="(max-width: 700px) 100vw, 700px" /></span></a><span class='text_holder'><span class='text_outer'><span class='text_inner'><span class='feature_holder'><span class="feature_holder_icons"><a itemprop='image' class='lightbox qbutton small white' title='Industrial Heater Unit (Class II, Div. II)' href='Assets/images/ashu8.webp' data-rel='prettyPhoto[pretty_photo_gallery]'>zoom</a><!-- <a itemprop='url' class='preview qbutton small white' href='http://www.hallelectrical.ca/portfolio_page/industrial-heater-unit/' target='_self'>view</a> --></span></span></span></span></span></div>
                                                            <div class='portfolio_description '>
                                                                <h5 itemprop="name" class="portfolio_title entry_title"><a itemprop="url" href="#" target="_self">Industrial work</a></h5>
                                                            </div>
                                                        </article>
                                                        <article class='mix portfolio_category_112 ' style=''>
                                                            <div class='image_holder'><a itemprop='url' class='portfolio_link_for_touch' href='#' target='_self'><span class='image'><img width="700" height="525" src="http://www.hallelectrical.ca/wp-content/uploads/2016/02/e44-1.jpeg" class="attachment-portfolio_masonry_with_space size-portfolio_masonry_with_space wp-post-image" alt="" srcset="http://www.hallelectrical.ca/wp-content/uploads/2016/02/e44-1.jpeg 3264w, http://www.hallelectrical.ca/wp-content/uploads/2016/02/e44-1-300x225.jpeg 300w, http://www.hallelectrical.ca/wp-content/uploads/2016/02/e44-1-768x576.jpeg 768w, http://www.hallelectrical.ca/wp-content/uploads/2016/02/e44-1-1024x768.jpeg 1024w" sizes="(max-width: 700px) 100vw, 700px" /></span></a><span class='text_holder'><span class='text_outer'><span class='text_inner'><span class='feature_holder'><span class="feature_holder_icons"><a itemprop='image' class='lightbox qbutton small white' title='More Portfolio Items Coming Soon' href='http://www.hallelectrical.ca/wp-content/uploads/2016/02/e44-1.jpeg' data-rel='prettyPhoto[pretty_photo_gallery]'>zoom</a><!-- <a itemprop='url' class='preview qbutton small white' href='http://www.hallelectrical.ca/portfolio_page/more-portfolio-items-coming-soon/' target='_self'>view</a> --></span></span></span></span></span></div>
                                                            <div class='portfolio_description '>
                                                                <h5 itemprop="name" class="portfolio_title entry_title"><a itemprop="url" href="#" target="_self">More Accessories Items Coming Soon</a></h5>
                                                            </div>
                                                        </article>
                                                        <div class='filler'></div>
                                                        <div class='filler'></div>
                                                        <div class='filler'></div>
                                                    </div>
                                                </div>
                                                <div class="separator  transparent   " style="margin-top: 20px;margin-bottom: 20px;"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="vc_row wpb_row section vc_row-fluid " style=' text-align:left;'> 
                                <div class=" full_section_inner clearfix">
                                    <div class="wpb_column vc_column_container vc_col-sm-12">
                                        <div class="vc_column-inner">
                                            <div class="wpb_wrapper">
                                                <div class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner">
                                                        <span class="empty_space_image"></span>
                                                    </span></div>


                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">


                                               


                                                        </div> 

                                                        <script>
                                                            (function($) {

                                                                // get the images of the gallery and replace it by a canvas of the same size to fix the problem with overlapping images on load.
                                                                $('img[width][height]:not(.uk-overlay-panel)', $('#wk-gridd1b')).each(function() {

                                                                    var $img = $(this);

                                                                    if (this.width == 'auto' || this.height == 'auto' || !$img.is(':visible')) {
                                                                        return;
                                                                    }

                                                                    var $canvas = $('<canvas class="uk-responsive-width"></canvas>').attr({
                                                                            width: $img.attr('width'),
                                                                            height: $img.attr('height')
                                                                        }),
                                                                        img = new Image,
                                                                        release = function() {
                                                                            $canvas.remove();
                                                                            $img.css('display', '');
                                                                            release = function() {};
                                                                        };

                                                                    $img.css('display', 'none').after($canvas);

                                                                    $(img).on('load', function() {
                                                                        release();
                                                                    });
                                                                    setTimeout(function() {
                                                                        release();
                                                                    }, 1000);

                                                                    img.src = this.src;

                                                                });

                                                            })(jQuery);
                                                        </script>


                                                    </div>
                                                </div>
                                                <div class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner">
                                                        <span class="empty_space_image"></span>
                                                    </span></div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>

                </div>
            </div>



            <?php include("footer.php");  ?>

        </div>
    </div>
    <?php include("jsscript.php"); ?>
</body>

</html>