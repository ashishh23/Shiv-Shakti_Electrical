<script type="text/javascript">
        document.addEventListener('wpcf7mailsent', function(event) {
            location = 'http://www.hallelectrical.ca/thank-you-contact';
        }, false);
    </script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var wpcf7 = {
            "apiSettings": {
                "root": "http:\/\/www.hallelectrical.ca\/wp-json\/contact-form-7\/v1",
                "namespace": "contact-form-7\/v1"
            }
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.1.5'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var QodeAdminAjax = {
            "ajaxurl": "http:\/\/www.hallelectrical.ca\/wp-admin\/admin-ajax.php"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/themes/bridge/js/default.min.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/themes/bridge/js/plugins.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/themes/bridge/js/plugins/jquery.mousewheel.min.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/plugins/qode-quick-links/assets/js/plugins/jquery.mCustomScrollbar.min.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/plugins/qode-quick-links/assets/js/qode-quick-links.min.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/tabs.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/plugins/timetable/js/jquery.ba-bbq.min.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/plugins/timetable/js/jquery.carouFredSel-6.2.1-packed.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/plugins/timetable/js/timetable.js?ver=5.3.11'></script>
    <script type='text/javascript' src='https://www.google.com/recaptcha/api.js?render=6LeGTMUUAAAAALnEdfoMdpF4qARqzHeG7fSj1Zo2&#038;ver=3.0'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var qodeLike = {
            "ajaxurl": "http:\/\/www.hallelectrical.ca\/wp-admin\/admin-ajax.php"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/themes/bridge/js/plugins/qode-like.min.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/accordion.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/position.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/menu.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=7.4.4'></script>
    <script type='text/javascript'>
        ('fetch' in window) || document.write('<script src="http://www.hallelectrical.ca/wp-includes/js/dist/vendor/wp-polyfill-fetch.min.js?ver=3.0.0"></scr' + 'ipt>');
        (document.contains) || document.write('<script src="http://www.hallelectrical.ca/wp-includes/js/dist/vendor/wp-polyfill-node-contains.min.js?ver=3.26.0-0"></scr' + 'ipt>');
        (window.FormData && window.FormData.prototype.keys) || document.write('<script src="http://www.hallelectrical.ca/wp-includes/js/dist/vendor/wp-polyfill-formdata.min.js?ver=3.0.12"></scr' + 'ipt>');
        (Element.prototype.matches && Element.prototype.closest) || document.write('<script src="http://www.hallelectrical.ca/wp-includes/js/dist/vendor/wp-polyfill-element-closest.min.js?ver=2.0.2"></scr' + 'ipt>');
    </script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/dist/dom-ready.min.js?ver=2.5.1'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/dist/a11y.min.js?ver=2.5.1'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var uiAutocompleteL10n = {
            "noResults": "No results found.",
            "oneResult": "1 result found. Use up and down arrow keys to navigate.",
            "manyResults": "%d results found. Use up and down arrow keys to navigate.",
            "itemSelected": "Item selected."
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/autocomplete.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/button.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'></script>
    <script type='text/javascript'>
        jQuery(document).ready(function(jQuery) {
            jQuery.datepicker.setDefaults({
                "closeText": "Close",
                "currentText": "Today",
                "monthNames": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                "monthNamesShort": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                "nextText": "Next",
                "prevText": "Previous",
                "dayNames": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                "dayNamesShort": ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                "dayNamesMin": ["S", "M", "T", "W", "T", "F", "S"],
                "dateFormat": "MM d, yy",
                "firstDay": 0,
                "isRTL": false
            });
        });
    </script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/mouse.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/resizable.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/draggable.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/dialog.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/droppable.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/progressbar.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/selectable.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/sortable.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/slider.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/spinner.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/tooltip.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-blind.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-bounce.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-clip.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-drop.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-explode.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-fade.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-fold.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-highlight.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-pulsate.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-size.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-scale.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-shake.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-slide.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/jquery/ui/effect-transfer.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/themes/bridge/js/plugins/jquery.carouFredSel-6.2.1.min.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/themes/bridge/js/plugins/lemmon-slider.min.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/themes/bridge/js/plugins/jquery.fullPage.min.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/themes/bridge/js/plugins/jquery.touchSwipe.min.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/plugins/js_composer/assets/lib/bower/isotope/dist/isotope.pkgd.min.js?ver=6.0.5'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/themes/bridge/js/plugins/packery-mode.pkgd.min.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/themes/bridge/js/plugins/jquery.stretch.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/themes/bridge/js/default_dynamic.js?ver=1570134695'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/themes/bridge/js/custom_js.js?ver=1570681569'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/comment-reply.min.js?ver=5.3.11'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=6.0.5'></script>
    <script type='text/javascript' src='http://www.hallelectrical.ca/wp-includes/js/wp-embed.min.js?ver=5.3.11'></script>
    <script type="text/javascript">
        (function(grecaptcha, sitekey, actions) {

            var wpcf7recaptcha = {

                execute: function(action) {
                    grecaptcha.execute(
                        sitekey, {
                            action: action
                        }
                    ).then(function(token) {
                        var forms = document.getElementsByTagName('form');

                        for (var i = 0; i < forms.length; i++) {
                            var fields = forms[i].getElementsByTagName('input');

                            for (var j = 0; j < fields.length; j++) {
                                var field = fields[j];

                                if ('g-recaptcha-response' === field.getAttribute('name')) {
                                    field.setAttribute('value', token);
                                    break;
                                }
                            }
                        }
                    });
                },

                executeOnHomepage: function() {
                    wpcf7recaptcha.execute(actions['homepage']);
                },

                executeOnContactform: function() {
                    wpcf7recaptcha.execute(actions['contactform']);
                },

            };

            grecaptcha.ready(
                wpcf7recaptcha.executeOnHomepage
            );

            document.addEventListener('change',
                wpcf7recaptcha.executeOnContactform, false
            );

            document.addEventListener('wpcf7submit',
                wpcf7recaptcha.executeOnHomepage, false
            );

        })(
            grecaptcha,
            '6LeGTMUUAAAAALnEdfoMdpF4qARqzHeG7fSj1Zo2', {
                "homepage": "homepage",
                "contactform": "contactform"
            }
        );
    </script>