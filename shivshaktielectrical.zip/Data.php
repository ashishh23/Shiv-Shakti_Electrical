<?php 
session_start();
if ($_SESSION['flag'] == "suc") {
    # code...
    
    

    include("connection.php");
    $select_query = "SELECT * FROM `Contact` WHERE 1";
    $mysqlresult = mysqli_query($con, $select_query);

    ?>
<!doctype html>




<!DOCTYPE html>
<html>
<title>Admin-panel</title>
<link rel="shortcut icon" type="image/x-icon" href="Assets/images/android-chrome-512x512.png">
    <link rel="apple-touch-icon" href="Assets/images/apple-touch-icon.png" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="Assets/css/w3.css">
<body>

<div class="w3-container">
  <!-- <h2>Colored Table Heading</h2>
  <p>Use any of the w3-<em>color</em> classes to display a colored row:</p> -->

  <table class="w3-table-all">
    <thead>
      <tr class="w3-red">
        <th>Sr No </th>

        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Mobile No</th>
        <th>Message</th>
        <th>DateTime</th>
        <th>Action</th>



      </tr>
    </thead>
   
   <?php
   $a =1;
    while($row = mysqli_fetch_assoc($mysqlresult)) { ?>
    <tr>
      <td><?php echo $a++; ?></td>
      <td><?php echo $row['first_name']; ?></td>
      <td><?php echo $row['last_name']; ?></td>
      <td><?php echo $row['email']; ?></td>
      <td><?php echo $row['phone']; ?></td>
      <td><?php echo $row['message']; ?></td>
      <td><?php echo $row['datetime']; ?></td>
      <td><a href="del.php?sno=<?php echo $row['sno']; ?>" class="w3-button w3-hover-red">DELETE</a> &nbsp;&nbsp;
    <a href="mailto://<?php echo $row['email']; ?>" class="w3-button w3-hover-aqua">MAIL</a></td>


      


    </tr>
<?php } ?>

  </table>
</div>

</body>
</html> 





    <?php

} else {
    echo "<h1 align='center'>Access Denied</h1>";
}
?>