    <!DOCTYPE html>
    <html lang="en-US" prefix="og: https://ogp.me/ns#">
    <?php include("headtag.php");

    require("connection.php"); ?>

    <body class="page-template page-template-contact-page page-template-contact-page-php page page-id-1452 qode-quick-links-1.0  qode-title-hidden qode-theme-ver-12.1.1 qode-theme-bridge wpb-js-composer js-comp-ver-6.0.5 vc_responsive" itemscope itemtype="http://schema.org/WebPage">
        <!--  Clickcease.com tracking-->
        <script type="text/javascript">
            var script = document.createElement("script");
            script.async = true;
            script.type = "text/javascript";
            var target = 'https://www.clickcease.com/monitor/stat.js';
            script.src = target;
            var elem = document.head;
            elem.appendChild(script);
        </script>
        <noscript><a href="https://www.clickcease.com" rel="nofollow"><img src="https://monitor.clickcease.com/stats/stats.aspx" alt="ClickCease" /></a></noscript>
        <!--  Clickcease.com tracking-->

        <div class="wrapper">
            <div class="wrapper_inner">


                <!-- Global site tag (gtag.js) - Google Analytics -->
                <script async src="https://www.googletagmanager.com/gtag/js?id=UA-112462302-1"></script>
                <script>
                    window.dataLayer = window.dataLayer || [];

                    function gtag() {
                        dataLayer.push(arguments);
                    }
                    gtag('js', new Date());

                    gtag('config', 'UA-112462302-1');
                </script>
                <!-- End Global site tag (gtag.js) - Google Analytics -->





                <?php include("header.php"); ?>

                <a id='back_to_top' href='#'>
                    <span class="fa-stack">
                        <i class="fa fa-arrow-up" style=""></i>
                    </span>
                </a>





                <div class="content ">
                    <div class="content_inner  ">
                        <div class="title_outer title_without_animation" data-height="416">
                            <div class="title title_size_large  position_left  has_fixed_background " style="background-size:1280px auto;background-image:url(Assets/images/ctu.jpg);height:416px;background-color:#F6F6F6;">
                                <div class="image not_responsive"><img itemprop="image" src="Assets/images/ctu.jpg" alt="&nbsp;" /> </div>
                                <div class="title_holder" style="padding-top:101px;height:315px;">
                                    <div class="container">
                                        <div class="container_inner clearfix">
                                            <div class="title_subtitle_holder">
                                                <div class="title_subtitle_holder_inner">
                                                    <h1 style="color: black;"><span>Contact Us</span></h1>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
    

     <!--    <div class="container" style="max-width: 500px;margin: auto;">

        <form action="<?php // echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <label for="">First Name</label><br>
            <input class="w3-input w3-border w3-hover-grey" type="text" name="your-firstname" id=""><br>
            <label for=""> Last Name</label><br>
            <input class="w3-input w3-border w3-hover-grey" type="text" name="your-lastname" id=""><br>
            <label  for=""> EmailName</label><br>
            <input class="w3-input w3-border w3-hover-grey" type="text" name="your-email" id=""><br>
            <label for="">Mobile No</label><br>
            <input class="w3-input w3-border w3-hover-grey" type="text" name="tel-248" id=""><br>
            <label for="">Massage</label><br>
            Pre Commented //  <input type="text" name="your-message" id=""><br> 
            <textarea class="w3-input w3-border w3-hover-grey" name="your-message"></textarea><br>

            <button class="w3-button w3-hover-red" type="submit" name="submit">Send Message</button>
        </form>


        </div> -->

<form method="POST">

        <div class="background">
  <div class="container">
    <div class="screen">
      <div class="screen-header">
        <div class="screen-header-left">
          <div class="screen-header-button close"></div>
          <div class="screen-header-button maximize"></div>
          <div class="screen-header-button minimize"></div>
        </div>
        <div class="screen-header-right">
          <div class="screen-header-ellipsis"></div>
          <div class="screen-header-ellipsis"></div>
          <div class="screen-header-ellipsis"></div>
        </div>
      </div>
      <div class="screen-body">
        <div class="screen-body-item left">
          <div class="app-title">
            <span>CONTACT</span>
            <span>US</span>
          </div>
          <div class="app-contact">CONTACT INFO : +91 8888682067</div>
        </div>
        <div class="screen-body-item">
          <div class="app-form">
            <div class="app-form-group">
              <input class="app-form-control" name="your-firstname" placeholder="First Name">
            </div>
            <div class="app-form-group">
              <input class="app-form-control" name="your-lastname" placeholder="Last Name">
            </div>
            <div class="app-form-group">
              <input class="app-form-control" type="email" name="your-email" placeholder="EMAIL">
            </div>
            <div class="app-form-group">
              <input class="app-form-control" name="tel-248" placeholder="CONTACT NO">
            </div>
            <div class="app-form-group message">
              <input class="app-form-control" name="your-message" placeholder="MESSAGE">
            </div>
            <div class="app-form-group buttons">
              <button class="app-form-button" type="clear">CANCEL</button>
              <button class="app-form-button" type="submit" name="submit">SEND</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- <div class="credits">
      inspired by
      <a class="credits-link" href="https://dribbble.com/shots/2666271-Contact" target="_blank">
        <svg class="dribbble" viewBox="0 0 200 200">
          <g stroke="#ffffff" fill="none">
            <circle cx="100" cy="100" r="90" stroke-width="20"></circle>
            <path d="M62.737004,13.7923523 C105.08055,51.0454853 135.018754,126.906957 141.768278,182.963345" stroke-width="20"></path>
            <path d="M10.3787186,87.7261455 C41.7092324,90.9577894 125.850356,86.5317271 163.474536,38.7920951" stroke-width="20"></path>
            <path d="M41.3611549,163.928627 C62.9207607,117.659048 137.020642,86.7137169 189.041451,107.858103" stroke-width="20"></path>
          </g>
        </svg>
        Gururaj
      </a>
    </div> -->
  </div>
</div>


</form>



        <?php
        // Auth --> Swapnil 
        // PHP Version --> 7.4.3


        if (isset($_POST['submit'])) {
            $first_name = $_POST['your-firstname'];
            $last_name = $_POST['your-lastname'];
            $phone_no = $_POST['tel-248'];
            $email_ad = $_POST['your-email'];
            $msg_user = $_POST['your-message'];
            $insert_query = "INSERT INTO `Contact`(`first_name`, `last_name`, `email`, `phone`, `message`) VALUES ('$first_name','$last_name','$email_ad','$phone_no','$msg_user')";
            $query = mysqli_query($con, $insert_query);
            if ($query) {
                echo "<script>alert('Message Sent');</script>";
            } else {
                echo "<script>alert('Internal Server Error');</script>";
            }
        }


        ?>


    </div>
    </div>
    </div>
    </div>
    <div class="wpb_column vc_column_container vc_col-sm-12">
        <div class="vc_column-inner">
            <div class="wpb_wrapper"></div>
        </div>
    </div>
    </div>
    </div>
    <div class="vc_row wpb_row section vc_row-fluid " style=' text-align:left;'>
        <div class=" full_section_inner clearfix">
            <div class="wpb_column vc_column_container vc_col-sm-12">
                <div class="vc_column-inner">
                    <div class="wpb_wrapper">
                        <div class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner">
                                <span class="empty_space_image"></span>
                            </span></div>






                        <div class="wpb_text_column wpb_content_element ">
                            <div class="wpb_wrapper">
 <!-- <div id="wk-grid886" class="uk-grid-width-1-1 uk-grid-width-large-1-5 uk-grid-width-xlarge-1-5 uk-grid uk-grid-match uk-text-center bottom-boxes" data-uk-grid-match="{target:'> div > .uk-panel', row:true}" data-uk-grid-margin >


    <div>
        <div class="uk-panel">

            
            
            
            
                        <h3 class="uk-panel-title">

                                    <a class="uk-link-reset" href="/electrical-car-charger-installation-vancouver/">EV CHARGERS</a>
                
                
            </h3>
            
            
                        <div class="uk-margin uk-text-center"><div class="uk-overlay uk-overlay-hover "><img src="/wp-content/plugins/widgetkit/cache/residential-solar-panel-installation-feature-f8a3e3a75075b1462782c2a4bdda0238.jpg" class=" uk-overlay-scale" alt="EV CHARGERS" width="150" height="100"><a class="uk-position-cover" href="/electrical-car-charger-installation-vancouver/" title="EV CHARGERS"></a></div></div>
            
            
            
            
            
        </div>
    </div>


    <div>
        <div class="uk-panel">

            
            
            
            
                        <h3 class="uk-panel-title">

                                    <a class="uk-link-reset" href="/electrical-panel-upgrades-electrical-service-upgrades/">RESIDENTIAL</a>
                
                
            </h3>
            
            
                        <div class="uk-margin uk-text-center"><div class="uk-overlay uk-overlay-hover "><img src="/wp-content/plugins/widgetkit/cache/Elementary-20-6ab9f0b0231342e1df77e441ee4f64eb.jpg" class=" uk-overlay-scale" alt="RESIDENTIAL" width="150" height="100"><a class="uk-position-cover" href="/electrical-panel-upgrades-electrical-service-upgrades/" title="RESIDENTIAL"></a></div></div>
            
            
            
            
            
        </div>
    </div>


    <div>
        <div class="uk-panel">

            
            
            
            
                        <h3 class="uk-panel-title">

                                    <a class="uk-link-reset" href="/services/commercial-electrical/">COMMERCIAL</a>
                
                
            </h3>
            
            
                        <div class="uk-margin uk-text-center"><div class="uk-overlay uk-overlay-hover "><img src="/wp-content/plugins/widgetkit/cache/AuraOpening-JR-171208-015_Credit-Joern-Rohde-cc61a6ef8bdb3ac3e95568ca5fc387ee.jpg" class=" uk-overlay-scale" alt="COMMERCIAL" width="150" height="100"><a class="uk-position-cover" href="/services/commercial-electrical/" title="COMMERCIAL"></a></div></div>
            
            
            
            
            
        </div>
    </div>


    <div>
        <div class="uk-panel">

            
            
            
            
                        <h3 class="uk-panel-title">

                                    <a class="uk-link-reset" href="/service-maintenance/">SERVICE & MAINTENANCE</a>
                
                
            </h3>
            
            
                        <div class="uk-margin uk-text-center"><div class="uk-overlay uk-overlay-hover "><img src="/wp-content/plugins/widgetkit/cache/farmhouse-staircase-fcd96c55dfc8b7f4ad49c6544ac03ee6.jpg" class=" uk-overlay-scale" alt="SERVICE &amp; MAINTENANCE" width="150" height="100"><a class="uk-position-cover" href="/service-maintenance/" title="SERVICE &amp; MAINTENANCE"></a></div></div>
            
            
            
            
            
        </div>
    </div>


    <div>
        <div class="uk-panel">

            
            
            
            
                        <h3 class="uk-panel-title">

                                    <a class="uk-link-reset" href="/careers/">CAREERS</a>
                
                
            </h3>
            
            
                        <div class="uk-margin uk-text-center"><div class="uk-overlay uk-overlay-hover "><img src="/wp-content/plugins/widgetkit/cache/Careers-Icon-e8f0cd7a13240f54c503b2f8b566dbcb.jpg" class=" uk-overlay-scale" alt="CAREERS" width="150" height="100"><a class="uk-position-cover" href="/careers/" title="CAREERS"></a></div></div>
            
            
            
            
            
        </div>
    </div>


</div> -->

                                <script>
                                    (function($) {

                                        // get the images of the gallery and replace it by a canvas of the same size to fix the problem with overlapping images on load.
                                        $('img[width][height]:not(.uk-overlay-panel)', $('#wk-grid886')).each(function() {

                                            var $img = $(this);

                                            if (this.width == 'auto' || this.height == 'auto' || !$img.is(':visible')) {
                                                return;
                                            }

                                            var $canvas = $('<canvas class="uk-responsive-width"></canvas>').attr({
                                                    width: $img.attr('width'),
                                                    height: $img.attr('height')
                                                }),
                                                img = new Image,
                                                release = function() {
                                                    $canvas.remove();
                                                    $img.css('display', '');
                                                    release = function() {};
                                                };

                                            $img.css('display', 'none').after($canvas);

                                            $(img).on('load', function() {
                                                release();
                                            });
                                            setTimeout(function() {
                                                release();
                                            }, 1000);

                                            img.src = this.src;

                                        });

                                    })(jQuery);
                                </script>


                            </div>
                        </div>
                        <div class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner">
                                <span class="empty_space_image"></span>
                            </span></div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>



    </div>
    </div>


    <?php include("footer.php"); ?>

    </div>
    </div>
    <?php include("jsscript.php"); ?>
</body>

</html>